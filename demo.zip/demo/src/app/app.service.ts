import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }

  getTime() {
    let currentTime = "http://worldclockapi.com/api/json/est/now";
    return this.http.get(currentTime);
  }
}
